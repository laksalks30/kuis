package kuislak;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import java.util.HashMap;
import java.util.Map;

public class BuyPage extends JFrame {
    private Map<String, Integer> fruitPrices;
    private Map<String, Integer> quantities;
    private String username;

    public BuyPage(String username, Map<String, Integer> quantities) {
        this.username = username;
        this.quantities = quantities;
        fruitPrices = new HashMap<>();

        // Set fruit prices
        fruitPrices.put("Apel", 15000);
        fruitPrices.put("Jeruk", 12000);
        fruitPrices.put("Mangga", 20000);

        setTitle("Halaman Pembelian");
        setSize(400, 400);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setLayout(new GridBagLayout());
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(5, 5, 5, 5);

        // Add title
        JLabel titleLabel = new JLabel("Rincian Pembelian", SwingConstants.CENTER);
        titleLabel.setFont(new Font("Arial", Font.BOLD, 16));
        gbc.gridx = 0;
        gbc.gridy = 0;
        gbc.gridwidth = 2;
        add(titleLabel, gbc);

        // Add fruit purchase details
        int row = 1;
        int totalAmount = 0;
        for (String fruit : fruitPrices.keySet()) {
            int quantity = quantities.getOrDefault(fruit, 0);
            if (quantity > 0) {
                int pricePerKg = fruitPrices.get(fruit);
                int totalFruitPrice = pricePerKg * quantity;
                totalAmount += totalFruitPrice;

                JPanel panel = new JPanel(new GridLayout(1, 3));
                panel.add(new JLabel(fruit));
                panel.add(new JLabel(quantity + " kg"));
                panel.add(new JLabel("Rp " + totalFruitPrice));

                gbc.gridx = 0;
                gbc.gridy = row++;
                gbc.gridwidth = 2;
                add(panel, gbc);
            }
        }

        // Add total amount
        JPanel totalPanel = new JPanel(new GridLayout(1, 2));
        totalPanel.add(new JLabel("Total Harga"));
        totalPanel.add(new JLabel("Rp " + totalAmount));
        gbc.gridx = 0;
        gbc.gridy = row++;
        gbc.gridwidth = 2;
        add(totalPanel, gbc);

        // Add buttons
        JButton confirmButton = new JButton("Konfirmasi Pembelian");
        confirmButton.addActionListener(e -> {
            JOptionPane.showMessageDialog(this, "Pembelian Berhasil!");
            dispose(); // Close the page after confirmation
        });
        gbc.gridx = 0;
        gbc.gridy = row++;
        gbc.gridwidth = 1;
        add(confirmButton, gbc);

        JButton cancelButton = new JButton("Batal");
        cancelButton.addActionListener(e -> {
            new HomePage(username); // Go back to HomePage
            dispose();
        });
        gbc.gridx = 1;
        gbc.gridy = row;
        gbc.gridwidth = 1;
        add(cancelButton, gbc);

        setVisible(true);
    }
}
