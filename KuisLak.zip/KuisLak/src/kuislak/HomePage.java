package kuislak;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import java.util.HashMap;
import java.util.Map;

public class HomePage extends JFrame {
    private String username;
    private Map<String, Integer> fruitPrices;
    private Map<String, JTextField> quantityFields;

    public HomePage(String username) {
        this.username = username;
        fruitPrices = new HashMap<>();
        quantityFields = new HashMap<>();

        // Set fruit prices
        fruitPrices.put("Apel", 15000);
        fruitPrices.put("Jeruk", 12000);
        fruitPrices.put("Mangga", 20000);

        setTitle("Halaman Utama");
        setSize(400, 350);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setLayout(new GridBagLayout());
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(5, 5, 5, 5);

        // Add welcome label
        JLabel welcomeLabel = new JLabel("Selamat Datang, " + username + "!", SwingConstants.CENTER);
        welcomeLabel.setFont(new Font("Arial", Font.BOLD, 16));
        gbc.gridx = 0;
        gbc.gridy = 0;
        gbc.gridwidth = 2;
        add(welcomeLabel, gbc);

        // Add fruit options
        int row = 1;
        for (String fruit : fruitPrices.keySet()) {
            JPanel panel = new JPanel(new BorderLayout());
            JLabel label = new JLabel(fruit + " - Rp" + fruitPrices.get(fruit) + "/kg");
            JTextField quantityField = new JTextField("0", 5);
            quantityFields.put(fruit, quantityField);
            panel.add(label, BorderLayout.WEST);
            panel.add(quantityField, BorderLayout.EAST);

            gbc.gridx = 0;
            gbc.gridy = row++;
            gbc.gridwidth = 2;
            gbc.fill = GridBagConstraints.HORIZONTAL;
            add(panel, gbc);
        }

        // Buy button
        JButton buyButton = new JButton("Beli");
        buyButton.setFont(new Font("Arial", Font.PLAIN, 14));
        buyButton.addActionListener(e -> handlePurchase());
        gbc.gridx = 0;
        gbc.gridy = row++;
        gbc.gridwidth = 1;
        add(buyButton, gbc);

        // Logout button
        JButton logoutButton = new JButton("Logout");
        logoutButton.setFont(new Font("Arial", Font.PLAIN, 14));
        logoutButton.addActionListener(e -> {
            new LoginPage();
            dispose();
        });
        gbc.gridx = 1;
        gbc.gridy = row;
        gbc.gridwidth = 1;
        add(logoutButton, gbc);

        setVisible(true);
    }

    private void handlePurchase() {
        for (Map.Entry<String, JTextField> entry : quantityFields.entrySet()) {
            try {
                int quantity = Integer.parseInt(entry.getValue().getText());
                if (quantity < 0) throw new NumberFormatException();
            } catch (NumberFormatException ex) {
                JOptionPane.showMessageDialog(this, "Masukkan jumlah valid untuk " + entry.getKey(), "Error", JOptionPane.ERROR_MESSAGE);
                return;
            }
        }
        JOptionPane.showMessageDialog(this, "Pembelian berhasil!");
    }
}
