package kuislak;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

public class LoginPage extends JFrame implements ActionListener {
    private JTextField usernameTextField;
    private JPasswordField passTextField;
    private JButton loginButton, resetButton;

    public LoginPage() {
        setTitle("Login");
        setSize(300, 200);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setLayout(new GridLayout(4, 1, 5, 5));

        // Username Field
        usernameTextField = new JTextField();
        add(createLabeledPanel("Username", usernameTextField));

        // Password Field
        passTextField = new JPasswordField();
        passTextField.addActionListener(e -> loginButton.doClick());
        add(createLabeledPanel("Password", passTextField));

        // Buttons Panel (Login & Reset)
        JPanel buttonPanel = new JPanel();
        loginButton = new JButton("Login");
        resetButton = new JButton("Reset");
        
        loginButton.addActionListener(this);
        resetButton.addActionListener(e -> {
            usernameTextField.setText("");
            passTextField.setText("");
        });

        buttonPanel.add(loginButton);
        buttonPanel.add(resetButton);
        add(buttonPanel);

        setVisible(true);
    }

    private JPanel createLabeledPanel(String label, JComponent field) {
        JPanel panel = new JPanel(new BorderLayout());
        panel.add(new JLabel(label), BorderLayout.WEST);
        panel.add(field, BorderLayout.CENTER);
        return panel;
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        String username = usernameTextField.getText();
        String password = new String(passTextField.getPassword());
        if ("laksa".equals(username) && "235".equals(password)) {
            JOptionPane.showMessageDialog(this, "Login Successful!");
            new HomePage(username);
            dispose();
        } else {
            JOptionPane.showMessageDialog(this, "Wrong username or password!", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }
}
